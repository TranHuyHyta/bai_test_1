import enum

class TypeEnum(enum.Enum):
    Order = "order"
    Cart = "cart"
    OrderDetail = "oder-detail"
    Cart_Item = "cart-item"